// Boost.Process
// Tests for file utilities.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "util/unit_test_main.hpp"
#include "boost/process/detail/handle.hpp"
#include "boost/test/unit_test.hpp"
#if defined(BOOST_POSIX_API)
    #include "boost/process/detail/posix_util.hpp"
    #include <unistd.h>
    #include <cstdlib>
    #include <cstring>
#elif defined(BOOST_WINDOWS_API)
    #include "boost/process/detail/windows_util.hpp"
    #define WIN32_LEAN_AND_MEAN
    #include <windows.h>
#endif

namespace bp = boost::processes;
namespace bpd = boost::processes::detail;
namespace butf = boost::unit_test::framework;

namespace {

#if defined(BOOST_WINDOWS_API)

void test_windows_dup()
{
    HANDLE rend, wend;
    BOOST_REQUIRE(::CreatePipe(&rend, &wend, 0, 0) != 0);
    bpd::handle rend_(rend);
    bpd::handle wend_(wend);

    DWORD flags;
    char buf[20];

    bpd::handle wend2(bpd::windows_dup(wend, false));
    BOOST_REQUIRE(::GetHandleInformation(wend2.native(), &flags) != 0);
    BOOST_REQUIRE(!(flags & HANDLE_FLAG_INHERIT));

    bpd::handle wend3(bpd::windows_dup(wend, true));
    BOOST_REQUIRE(::GetHandleInformation(wend3.native(), &flags) != 0);
    BOOST_REQUIRE(flags & HANDLE_FLAG_INHERIT);

    DWORD rcnt;

    BOOST_REQUIRE(::WriteFile(wend, "test-windows-dup", 19, &rcnt, 0) != 0);
    BOOST_REQUIRE_EQUAL(rcnt, 19);
    BOOST_REQUIRE(::ReadFile(rend, buf, sizeof(buf), &rcnt, 0) != 0);
    BOOST_REQUIRE_EQUAL(rcnt, 19);
    buf[19] = '\0';
    BOOST_REQUIRE(std::strcmp(buf, "test-windows-dup") == 0);

    BOOST_REQUIRE(::WriteFile(wend2.native(), "test-windows-dup", 19, &rcnt,
                              0) != 0);
    BOOST_REQUIRE_EQUAL(rcnt, 19);
    BOOST_REQUIRE(::ReadFile(rend, buf, sizeof(buf), &rcnt, 0) != 0);
    BOOST_REQUIRE_EQUAL(rcnt, 19);
    buf[19] = '\0';
    BOOST_REQUIRE(std::strcmp(buf, "test-windows-dup") == 0);

    BOOST_REQUIRE(::WriteFile(wend3.native(), "test-windows-dup", 19, &rcnt,
                              0) != 0);
    BOOST_REQUIRE_EQUAL(rcnt, 19);
    BOOST_REQUIRE(::ReadFile(rend, buf, sizeof(buf), &rcnt, 0) != 0);
    BOOST_REQUIRE_EQUAL(rcnt, 19);
    buf[19] = '\0';
    BOOST_REQUIRE(std::strcmp(buf, "test-windows-dup") == 0);
}

void test_windows_set_inheritable()
{
    HANDLE rend, wend;
    BOOST_REQUIRE(::CreatePipe(&rend, &wend, 0, 0) != 0);
    bpd::handle rend_(rend);
    bpd::handle wend_(wend);

    DWORD flags;

    bpd::handle wend2(bpd::windows_dup(wend, false));
    BOOST_REQUIRE(::GetHandleInformation(wend2.native(), &flags) != 0);
    BOOST_REQUIRE(!(flags & HANDLE_FLAG_INHERIT));

    bpd::handle wend3(bpd::windows_dup(wend, true));
    BOOST_REQUIRE(::GetHandleInformation(wend3.native(), &flags) != 0);
    BOOST_REQUIRE(flags & HANDLE_FLAG_INHERIT);
}

#endif // #if defined(BOOST_WINDOWS_API)

#if defined(BOOST_POSIX_API)

void test_posix_dup2()
{
    int pfd[2];
    BOOST_REQUIRE(::pipe(pfd) != -1);
    int rend = pfd[0];
    int wend = pfd[1];
    bpd::handle rend_(rend);
    bpd::handle wend_(wend);

    BOOST_REQUIRE(rend != 10);
    BOOST_REQUIRE(wend != 10);
    bpd::handle d(10);
    bpd::posix_dup2(wend, d.native());

    BOOST_REQUIRE(::write(wend, "test-posix-dup", 14) != -1);
    char buf1[15];
    BOOST_REQUIRE_EQUAL(::read(rend, buf1, sizeof(buf1)), 14);
    buf1[14] = '\0';
    BOOST_REQUIRE(std::strcmp(buf1, "test-posix-dup") == 0);

    BOOST_REQUIRE(::write(d.native(), "test-posix-dup", 14) != -1);
    char buf2[15];
    BOOST_REQUIRE_EQUAL(::read(rend, buf2, sizeof(buf2)), 14);
    buf2[14] = '\0';
    BOOST_REQUIRE(std::strcmp(buf2, "test-posix-dup") == 0);
}

#endif // #if defined(BOOST_POSIX_API)

} // namespace {

bool init_unit_test()
{
#if defined(BOOST_WINDOWS_API)
    butf::master_test_suite().add(BOOST_TEST_CASE(test_windows_dup));
    butf::master_test_suite().add(BOOST_TEST_CASE(
        test_windows_set_inheritable));
#elif defined(BOOST_POSIX_API)
    butf::master_test_suite().add(BOOST_TEST_CASE(test_posix_dup2));
#endif
    return true;
}

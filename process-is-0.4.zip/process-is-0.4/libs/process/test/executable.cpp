// Boost.Process
// Tests for command line construction class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "util/unit_test_main.hpp"
#include "util/use_helpers.hpp"
#include "boost/process/launch.hpp"
#include "boost/process/utility.hpp"
#include "boost/test/unit_test.hpp"

#if defined(BOOST_WINDOWS_API)
    #include <windows.h>
#elif defined(BOOST_POSIX_API)
    #include <stdlib.h>
#endif

#include <string>

namespace bfs = boost::filesystem;
namespace bp = boost::processes;
namespace butf = boost::unit_test::framework;

namespace {

// A predicate for BOOST_CHECK_EXCEPTION that always fails.
class check_name
{
    std::string name_;

public:
    check_name(const std::string& name):
        name_(name)
    {}

    bool operator()(const boost::system::system_error& e) const
    {
        return true;
    }
};

void test_find_default()
{
    std::string helpersname = bfs::path(get_helpers_path()).leaf();
    BOOST_CHECK_EXCEPTION(bp::find_executable_in_path(helpersname),
                          boost::system::system_error,
                          check_name(helpersname));
}

void test_find_env()
{
    bfs::path orig = get_helpers_path();
    std::string helpersdir = orig.branch_path().string();
    std::string helpersname = orig.leaf();

#if defined(BOOST_POSIX_API)
    std::string oldpath = ::getenv("PATH");
    try {
        ::setenv("PATH", helpersdir.c_str(), 1);
        bfs::path found = bp::find_executable_in_path(helpersname);
        BOOST_CHECK(bfs::equivalent(orig, found));
        ::setenv("PATH", oldpath.c_str(), 1);
    } catch (...) {
        ::setenv("PATH", oldpath.c_str(), 1);
    }
#elif defined(BOOST_WINDOWS_API)
    char oldpath[MAX_PATH];
    BOOST_REQUIRE(::GetEnvironmentVariable("PATH", oldpath, MAX_PATH) != 0);
    try {
        BOOST_REQUIRE(::SetEnvironmentVariable("PATH",
                                               helpersdir.c_str()) != 0);
        bfs::path found = bp::find_executable_in_path(helpersname);
        BOOST_CHECK(bfs::equivalent(orig, found));
        BOOST_REQUIRE(::SetEnvironmentVariable("PATH", oldpath) != 0);
    } catch (...) {
        BOOST_REQUIRE(::SetEnvironmentVariable("PATH", oldpath) != 0);
    }
#endif
}

void test_find_param()
{
    bfs::path orig = get_helpers_path();
    std::string helpersdir = orig.branch_path().string();
    std::string helpersname = orig.leaf();
    bfs::path found = bp::find_executable_in_path(helpersname, helpersdir);
    BOOST_CHECK(bfs::equivalent(orig, found));
}

} // namespace {

bool init_unit_test()
{
    check_helpers();
    butf::master_test_suite().add(BOOST_TEST_CASE(test_find_default));
    butf::master_test_suite().add(BOOST_TEST_CASE(test_find_env));
    butf::master_test_suite().add(BOOST_TEST_CASE(test_find_param));
    return true;
}

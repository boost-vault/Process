// Boost.Process
// Tests for the launcher class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "launch.hpp"
#include "util/unit_test_main.hpp"
#include "util/use_helpers.hpp"
#include "boost/process/child.hpp"
#include "boost/process/context.hpp"
#include "boost/process/launch.hpp"
#include "boost/filesystem/operations.hpp"
#include "boost/test/unit_test.hpp"

namespace bp = boost::processes;
namespace butf = boost::unit_test::framework;

namespace {

struct launcher
{
    bp::child
    operator()(const std::vector<std::string> args,
               const bp::context& ctx,
               bool = false) const
    {
        return bp::launch(get_helpers_path(), args, ctx);
    }
};

} // namespace {

bool init_unit_test()
{
    check_helpers();
    launch_tests::add<launcher, bp::context, bp::child>
        (butf::master_test_suite());
    return true;
}

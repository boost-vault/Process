// Boost.Process
// Tests for the self class.
//
// Copyright (c) 2006, 2007 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "util/unit_test_main.hpp"
#include "boost/process/config.hpp"
#include "boost/process/self.hpp"
#include "boost/test/unit_test.hpp"

#if defined(BOOST_WINDOWS_API)
    #include <windows.h>
#elif defined(BOOST_POSIX_API)
    #include <unistd.h>
#endif

namespace bp = boost::processes;
namespace butf = boost::unit_test::framework;

namespace {

struct launcher
{
    bp::self&
    operator()(bp::process::native_id_type id) const
    {
        return bp::self::get_instance();
    }
};

void test_id()
{
    bp::self& p = bp::self::get_instance();

#if defined(BOOST_POSIX_API)
    BOOST_REQUIRE(p.native_id() == ::getpid());
#elif defined(BOOST_WINDOWS_API)
    BOOST_REQUIRE(p.native_id() == ::GetCurrentProcessId());
#endif
}

void test_get_environment()
{
    bp::self& p = bp::self::get_instance();

    bp::environment env1 = p.get_environment();
    BOOST_CHECK(env1.find("THIS_SHOULD_NOT_BE_DEFINED") == env1.end());

#if defined(BOOST_POSIX_API)
    BOOST_REQUIRE(::setenv("THIS_SHOULD_BE_DEFINED", "some-value", 1) == 0);
#elif defined(BOOST_WINDOWS_API)
    BOOST_REQUIRE(::SetEnvironmentVariable("THIS_SHOULD_BE_DEFINED",
                                           "some-value") != 0);
#endif

    bp::environment env2 = p.get_environment();
    bp::environment::const_iterator iter =
        env2.find("THIS_SHOULD_BE_DEFINED");
    BOOST_CHECK(iter != env2.end());
    BOOST_CHECK_EQUAL(iter->second, "some-value");
}

} // namespace {

bool init_unit_test()
{
    butf::master_test_suite().add(BOOST_TEST_CASE(test_id));
    butf::master_test_suite().add(BOOST_TEST_CASE(test_get_environment));
    return true;
}

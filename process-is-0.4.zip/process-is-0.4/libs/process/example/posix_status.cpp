// Boost.Process
//
// Copyright (c) 2006 Julio M. Merino Vidal.
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

// This example program demonstrates how to retrieve extended exit status
// under a POSIX system. The program starts the command line passed to it
// as arguments and shows its termination information.

// Avoid building this example under non-POSIX systems.
#include "boost/process/config.hpp"
#if defined(BOOST_POSIX_API)

//[posix_status_all
#include <unistd.h>

#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

#include "boost/process.hpp"

namespace bp = boost::processes;

int main(int argc, char* argv[])
{
    if (argc < 2) {
        std::cerr << "Please provide a program name." << std::endl;
        return EXIT_FAILURE;
    }

    // Constructs a command line based on the arguments provided to the
    // program.
    //
    std::string exe = argv[1];
    std::vector<std::string> args;
    args.push_back(exe);
    for (int i = 2; i < argc; i++)
        args.push_back(argv[i]);

    // Spawns the new child process.
    //
    bp::child c = bp::launch(exe, args, bp::context());

    // Waits until the process exits and parses its termination status.
    // Note that we receive a posix::status object even when the wait()
    // method returns a status one.
    //
    const bp::status s = c.wait();
    if (s.exited()) {
        std::cout << "Program returned exit code " << s.exit_status()
                  << std::endl;
    } else if (s.signaled()) {
        std::cout << "Program received signal " << s.term_signal()
                  << std::endl;
        if (s.dumped_core())
            std::cout << "Program also dumped core" << std::endl;
    } else if (s.stopped()) {
        std::cout << "Program stopped by signal" << s.stop_signal()
                  << std::endl;
    } else {
        std::cout << "Unknown termination reason" << std::endl;
    }

    return s.exited() ? s.exit_status() : EXIT_FAILURE;
}
//]

#else // !defined(BOOST_POSIX_API)

#include <cstdlib>
#include <iostream>

int main(int argc, char* argv[])
{
    std::cerr << "This example program is not supported in this platform."
              << std::endl;
    return EXIT_FAILURE;
}

#endif // defined(BOOST_POSIX_API)

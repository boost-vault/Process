// Boost.Process
//
// Copyright (c) 2006 Julio M. Merino Vidal.
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

// This example program demonstrates multiple ways to modify a new child's
// environment variables.

//[environment_all
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

#include "boost/process.hpp"

namespace bp = boost::processes;

namespace {

// Helper function that forks a new process that shows the contents of
// the environment configured by the given launcher.
//
void run_it(const std::string& msg, const bp::context& ctx)
{
    bp::context ctx2 = ctx;
    ctx2.streams_behavior.clear();
    ctx2.add(bp::close_stream(bp::stdin_fileno))
        .add(bp::inherit_stream(bp::stdout_fileno))
        .add(bp::redirect_to_stdout(bp::stderr_fileno));

    std::cout << "===> " << msg << std::endl;
#if defined(BOOST_POSIX_API)
    std::vector<std::string> args;
    args.push_back("env");
    const bp::status s =
        bp::launch(bp::find_executable_in_path("env"), args, ctx2).wait();
#elif defined(BOOST_WINDOWS_API)
    const bp::status s = bp::launch_shell("set", ctx2).wait();
#endif
    if (s.exited() && s.exit_status() == EXIT_SUCCESS)
        std::cout << "     *** SUCCESS ***" << std::endl;
    else
        std::cout << "     *** FAILURE ***" << std::endl;
    std::cout << std::endl;
}

} // namespace {

int main(int argc, char* argv[])
{
    // This first launcher does not touch the environment in the context
    // so it will be empty.
    //
    bp::context ctx1;
    run_it("Clean environment", ctx1);

    // This second example obtains a snapshot of the current environment
    // and passes it down to the child process.
    //
    bp::context ctx2;
    ctx2.environment = bp::current_environment();
    run_it("Inherited environment", ctx2);

    // This example adds an extra variable to the environment.
    //
    bp::context ctx3;
    ctx3.environment = bp::current_environment();
    ctx3.environment.insert
        (bp::environment::value_type("NEW_VARIABLE", "Hello, world!"));
    run_it("Environment with the NEW_VARIABLE extra variable", ctx3);

    // This example removes a standard variable from the environment.
    //
    bp::context ctx4;
    ctx4.environment = bp::current_environment();
    ctx4.environment.erase("PATH");
    run_it("Environment without the standard PATH variable", ctx4);


    // This last example illustrates how to start up a new child process
    // with a completely controlled environment table that is not subject
    // to existing variables at all.
    //
    bp::context ctx5;
    ctx5.environment.insert
        (bp::environment::value_type("HOME", "Known value for HOME"));
    ctx5.environment.insert
        (bp::environment::value_type("PATH", "Known value for PATH"));
    run_it("Completely controlled environment", ctx5);

    return EXIT_SUCCESS;
}
//]

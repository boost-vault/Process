// Boost.Process
// Helper utilities for tests that launch child processes.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "boost/process/config.hpp"

#if defined(BOOST_PROCESS_POSIX_API)
#elif defined(BOOST_PROCESS_WIN32_API)
    #define WIN32_LEAN_AND_MEAN
    #include <windows.h>
#else
    #error "Unsupported platform."
#endif

#include "boost/filesystem/operations.hpp"

#include <iostream>
#include <string>
#include <cstdlib>

namespace bfs = boost::filesystem;

namespace {

int echo_quoted(int argc, char* argv[])
{
    std::cout << ">>>" << argv[1] << "<<<";
    return EXIT_SUCCESS;
}

int echo_stdout(int argc, char* argv[])
{
    std::cout << argv[1];
    return EXIT_SUCCESS;
}

int echo_stderr(int argc, char* argv[])
{
    std::cerr << argv[1];
    return EXIT_SUCCESS;
}

int echo_stdout_stderr(int argc, char* argv[])
{
    std::cout << "stdout " << argv[1] << std::endl;
    std::cout.flush();
    std::cerr << "stderr " << argv[1] << std::endl;
    std::cerr.flush();
    return EXIT_SUCCESS;
}

int exit_failure(int argc, char* argv[])
{
    return EXIT_FAILURE;
}

int exit_success(int argc, char* argv[])
{
    return EXIT_SUCCESS;
}

int is_closed_stdin(int argc, char* argv[])
{
    std::string word;
    std::cin >> word;
    return std::cin.eof() ? EXIT_SUCCESS : EXIT_FAILURE;
}

int is_closed_stdout(int argc, char* argv[])
{
    std::cout << "foo" << std::endl;
    return std::cout.bad() ? EXIT_SUCCESS : EXIT_FAILURE;
}

int is_closed_stderr(int argc, char* argv[])
{
    std::cerr << "foo" << std::endl;
    return std::cerr.bad() ? EXIT_SUCCESS : EXIT_FAILURE;
}

int loop(int argc, char* argv[])
{
    for (;;);
    return EXIT_SUCCESS;
}

int prefix(int argc, char* argv[])
{
    std::string line;
    while (std::getline(std::cin, line))
        std::cout << argv[1] << line << std::endl;
    return EXIT_SUCCESS;
}

int pwd(int argc, char* argv[])
{
    std::cout << bfs::current_path().string();
    return EXIT_SUCCESS;
}

int query_env(int argc, char* argv[])
{
#if defined(BOOST_PROCESS_WIN32_API)
    TCHAR buf[1024];
    DWORD res = \
        ::GetEnvironmentVariable(TEXT(argv[1]), (LPTSTR) &buf, sizeof(buf));
    std::cout << (res ? buf : "undefined");
#elif defined(BOOST_PROCESS_POSIX_API)
    const char* value = ::getenv(argv[1]);
    std::cout << (value ? value : "undefined");
#endif // #elif defined(BOOST_PROCESS_POSIX_API)
    return EXIT_SUCCESS;
}

int stdin_to_stdout(int argc, char* argv[])
{
    char ch;
    while (std::cin >> ch)
        std::cout << ch;
    return EXIT_SUCCESS;
}

#if defined(BOOST_PROCESS_POSIX_API)
int posix_echo_one(int argc, char* argv[])
{
    int desc = std::atoi(argv[1]);
    std::size_t len = std::strlen(argv[2]);
    return write(desc, argv[2], len) == ssize_t(len) ? 0 : 1;
}

int posix_echo_two(int argc, char* argv[])
{
    int desc1 = std::atoi(argv[1]);
    int desc2 = std::atoi(argv[2]);

    write(desc1, argv[1], std::strlen(argv[1]));
    write(desc1, " ", 1);
    write(desc1, argv[3], std::strlen(argv[3]));
    write(desc1, "\n", 1);

    write(desc2, argv[2], std::strlen(argv[2]));
    write(desc2, " ", 1);
    write(desc2, argv[3], std::strlen(argv[3]));
    write(desc2, "\n", 1);

    return EXIT_SUCCESS;
}
#endif // #if defined(BOOST_PROCESS_POSIX_API)

#if defined(BOOST_PROCESS_WIN32_API)
int win32_print_startupinfo(int argc, char* argv[])
{
    STARTUPINFO si;
    ::GetStartupInfo(&si);
    std::cout << "dwFlags = " << si.dwFlags << std::endl;
    std::cout << "dwX = " << si.dwX << std::endl;
    std::cout << "dwY = " << si.dwY << std::endl;
    std::cout << "dwXSize = " << si.dwXSize << std::endl;
    std::cout << "dwYSize = " << si.dwYSize << std::endl;

    return EXIT_SUCCESS;
}
#endif // #if defined(BOOST_PROCESS_WIN32_API)

} // namespace {

struct helper {
    const char* name;
    int (*entry)(int, char*[]);
    int min_argc;
    const char* syntax;
}
  helpers[] = {
    { "echo-quoted", echo_quoted, 2, "word" },
    { "echo-stdout", echo_stdout, 2, "message" },
    { "echo-stderr", echo_stderr, 2, "message" },
    { "echo-stdout-stderr", echo_stdout_stderr, 2, "message" },
    { "exit-failure", exit_failure, 1, "" },
    { "exit-success", exit_success, 1, "" },
    { "is-closed-stdin", is_closed_stdin, 1, "" },
    { "is-closed-stdout", is_closed_stdout, 1, "" },
    { "is-closed-stderr", is_closed_stderr, 1, "" },
    { "loop", loop, 1, "" },
    { "prefix", prefix, 2, "string" },
    { "pwd", pwd, 1, "" },
    { "query-env", query_env, 2, "variable" },
    { "stdin-to-stdout", stdin_to_stdout, 1, "" },

#if defined(BOOST_PROCESS_POSIX_API)
    { "posix-echo-one", posix_echo_one, 3, "desc message" },
    { "posix-echo-two", posix_echo_two, 4, "desc1 desc2 message" },
#elif defined(BOOST_PROCESS_WIN32_API)
    { "win32-print-startupinfo", win32_print_startupinfo, 1, "" },
#endif

    { 0 }
};

int main(int argc, char* argv[])
{
    if (argc < 2) {
        std::cerr << "helpers: missing command" << std::endl;
        return 128;
    }

    std::string command(argv[1]);
    argc--; argv++;

    struct helper* h = helpers;
    while (h->name != 0) {
        if (command == h->name) {
            int res;
            if (argc < h->min_argc) {
                std::cerr << "helpers: command syntax: `" << command << " "
                          << h->syntax << "'" << std::endl;
                res = 128;
            } else
                res = (*h->entry)(argc, argv);
            return res;
        }
        h++;
    }

    std::cerr << "helpers: invalid command `" << command << "'" << std::endl;
    return 128;
}

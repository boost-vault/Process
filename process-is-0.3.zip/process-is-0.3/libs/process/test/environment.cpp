// Boost.Process
// Tests for the environment class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "util/unit_test_main.hpp"
#include "boost/process/environment.hpp"
#include "boost/test/unit_test.hpp"
#if defined(BOOST_PROCESS_POSIX_API)
    #include "boost/process/detail/posix_ops.hpp"
    #include <cstdlib>
#elif defined(BOOST_PROCESS_WIN32_API)
    #include "boost/process/detail/win32_ops.hpp"
    #include <tchar.h>
    #include <cstring>
#else
    #error "Unsupported platform."
#endif

namespace bp = boost::process;
namespace bpd = boost::process::detail;
namespace butf = boost::unit_test::framework;

namespace {

void test_current()
{
    bp::environment env1 = bp::current_environment();
    BOOST_CHECK(env1.find("THIS_SHOULD_NOT_BE_DEFINED") == env1.end());

#if defined(BOOST_PROCESS_POSIX_API)
    BOOST_REQUIRE(::setenv("THIS_SHOULD_BE_DEFINED", "some-value", 1) == 0);
#elif defined(BOOST_PROCESS_WIN32_API)
    BOOST_REQUIRE(::SetEnvironmentVariable(TEXT("THIS_SHOULD_BE_DEFINED"),
                                           TEXT("some-value")) != 0);
#endif

    bp::environment env2 = bp::current_environment();
    bp::environment::const_iterator iter =
        env2.find("THIS_SHOULD_BE_DEFINED");
    BOOST_CHECK(iter != env2.end());
    BOOST_CHECK_EQUAL(iter->second, "some-value");
}

#if defined(BOOST_PROCESS_POSIX_API)
void test_envp()
{
    bp::environment env;
    env.insert(bp::environment::value_type("VAR1", "value1"));
    env.insert(bp::environment::value_type("VAR2", "value2"));
    env.insert(bp::environment::value_type("VAR3", "value3"));

    char** ep = bpd::environment_to_envp(env);

    BOOST_REQUIRE(ep[0] != 0);
    BOOST_REQUIRE_EQUAL(std::string(ep[0]), "VAR1=value1");
    delete [] ep[0];

    BOOST_REQUIRE(ep[1] != 0);
    BOOST_REQUIRE_EQUAL(std::string(ep[1]), "VAR2=value2");
    delete [] ep[1];

    BOOST_REQUIRE(ep[2] != 0);
    BOOST_REQUIRE_EQUAL(std::string(ep[2]), "VAR3=value3");
    delete [] ep[2];

    BOOST_REQUIRE(ep[3] == 0);
    delete [] ep;
}

void test_envp_unsorted()
{
    bp::environment env;
    env.insert(bp::environment::value_type("VAR2", "value2"));
    env.insert(bp::environment::value_type("VAR1", "value1"));

    char** ep = bpd::environment_to_envp(env);

    BOOST_REQUIRE(ep[0] != 0);
    BOOST_REQUIRE_EQUAL(std::string(ep[0]), "VAR1=value1");
    delete [] ep[0];

    BOOST_REQUIRE(ep[1] != 0);
    BOOST_REQUIRE_EQUAL(std::string(ep[1]), "VAR2=value2");
    delete [] ep[1];

    BOOST_REQUIRE(ep[2] == 0);
    delete [] ep;
}
#endif // #if defined(BOOST_PROCESS_POSIX_API)

#if defined(BOOST_PROCESS_WIN32_API)
void test_strings()
{
    bp::environment env;
    env.insert(bp::environment::value_type("VAR1", "value1"));
    env.insert(bp::environment::value_type("VAR2", "value2"));
    env.insert(bp::environment::value_type("VAR3", "value3"));

    boost::shared_array<TCHAR> strs =
        bpd::environment_to_win32_strings(env);
    BOOST_REQUIRE(strs.get() != 0);

    TCHAR* expected = TEXT("VAR1=value1\0VAR2=value2\0VAR3=value3\0\0");
    BOOST_REQUIRE(std::memcmp(strs.get(), expected,
                              37 * sizeof(TCHAR)) == 0);
}

void test_strings_unsorted()
{
    bp::environment env;
    env.insert(bp::environment::value_type("VAR2", "value2"));
    env.insert(bp::environment::value_type("VAR1", "value1"));

    boost::shared_array<TCHAR> strs =
        bpd::environment_to_win32_strings(env);
    BOOST_REQUIRE(strs.get() != 0);

    TCHAR* expected = TEXT("VAR1=value1\0VAR2=value2\0\0");
    BOOST_REQUIRE(std::memcmp(strs.get(), expected,
                              25 * sizeof(TCHAR)) == 0);
}
#endif // #if defined(BOOST_PROCESS_WIN32_API)

} // namespace {

bool init_unit_test()
{
    butf::master_test_suite().add(BOOST_TEST_CASE(test_current));
#if defined(BOOST_PROCESS_POSIX_API)
    butf::master_test_suite().add(BOOST_TEST_CASE(test_envp));
    butf::master_test_suite().add(BOOST_TEST_CASE(test_envp_unsorted));
#elif defined(BOOST_PROCESS_WIN32_API)
    butf::master_test_suite().add(BOOST_TEST_CASE(test_strings));
    butf::master_test_suite().add(BOOST_TEST_CASE(test_strings_unsorted));
#endif
    return true;
}

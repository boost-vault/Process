// Boost.Process
// Tests for shell constructors.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "util/unit_test_main.hpp"
#include "util/use_helpers.hpp"
#include "boost/process/child.hpp"
#include "boost/process/context.hpp"
#include "boost/process/operations.hpp"
#include "boost/process/status.hpp"
#include "boost/iostreams/stream.hpp"
#include "boost/test/unit_test.hpp"
#include <cstdlib>
#include <string>

namespace bp = boost::process;
namespace bios = boost::iostreams;
namespace butf = boost::unit_test::framework;

namespace {

void test_shell_execution()
{
    std::string command;
    bp::context ctx;

#if defined(BOOST_PROCESS_POSIX_API)
    command = "echo test | sed 's,^,LINE-,'";
    ctx.output_behavior.insert(std::make_pair(
        STDOUT_FILENO, bp::capture_stream()));
    // XXX Without the following line, bash returns an exit status of 4,
    // which makes the test fail... Why?  I don't know.
    ctx.output_behavior.insert(std::make_pair(
        STDERR_FILENO, bp::redirect_stream_to_stdout()));
#elif defined(BOOST_PROCESS_WIN32_API)
    command = "if foo==foo echo LINE-test";
    ctx.stdout_behavior = bp::capture_stream();
#endif

    bp::child c = bp::launch_shell(command, ctx);

    bios::stream<bios::file_descriptor> is(c.get_stdout());
    std::string word;
    is >> word;
    BOOST_CHECK_EQUAL(word, "LINE-test");

    const bp::status s = c.wait();
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_SUCCESS);
}

} // namespace {

bool init_unit_test()
{
    check_helpers();
    butf::master_test_suite().add(BOOST_TEST_CASE(test_shell_execution));
    return true;
}

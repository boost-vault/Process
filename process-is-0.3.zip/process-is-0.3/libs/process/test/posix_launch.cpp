// Boost.Process
// Tests for the posix::launch class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "boost/process/config.hpp"

#if defined(BOOST_PROCESS_POSIX_API)

#include "launch.hpp"
#include "util/use_helpers.hpp"
#include "util/unit_test_main.hpp"
#include "boost/process/child.hpp"
#include "boost/process/context.hpp"
#include "boost/process/operations.hpp"
#include "boost/filesystem/operations.hpp"
#include "boost/format.hpp"
#include "boost/iostreams/stream.hpp"
#include "boost/test/unit_test.hpp"
#include <cstring>
#include <string>

namespace bfs = boost::filesystem;
namespace bp = boost::process;
namespace bios = boost::iostreams;
namespace butf = boost::unit_test::framework;

namespace {

struct launcher
{
    bp::child
    operator()(const std::vector<std::string> args,
               bp::context ctx,
               bp::stream_behavior bstdin = bp::close_stream(),
               bp::stream_behavior bstdout = bp::close_stream(),
               bp::stream_behavior bstderr = bp::close_stream(),
               bool usein = false) const
    {
        if (!boost::get<bp::close_stream>(&bstdin))
            ctx.input_behavior.insert(std::make_pair(STDIN_FILENO, bstdin));
        if (!boost::get<bp::close_stream>(&bstdout))
            ctx.output_behavior.insert(std::make_pair(STDOUT_FILENO, bstdout));
        if (!boost::get<bp::close_stream>(&bstderr))
            ctx.output_behavior.insert(std::make_pair(STDERR_FILENO, bstderr));
        return bp::launch(get_helpers_path(), args, ctx);
    }
};

void test_input()
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("stdin-to-stdout");

    bp::context ctx;
    ctx.input_behavior.insert(std::make_pair(
        STDIN_FILENO, bp::capture_stream()));
    ctx.output_behavior.insert(std::make_pair(
        STDOUT_FILENO, bp::capture_stream()));
    bp::child c = bp::launch(get_helpers_path(), args, ctx);

    bios::stream<bios::file_descriptor> os(c.get_input(STDIN_FILENO));
    bios::stream<bios::file_descriptor> is(c.get_output(STDOUT_FILENO));

    os << "message-to-process" << std::endl;
    os.close();

    std::string word;
    is >> word;
    BOOST_CHECK_EQUAL(word, "message-to-process");

    const bp::status s = c.wait();
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_SUCCESS);
}

void check_output(int desc, const std::string& msg)
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("posix-echo-one");
    args.push_back(boost::str(boost::format("%1%") % desc));
    args.push_back(msg);

    bp::context ctx;
    ctx.output_behavior.insert(std::make_pair(desc, bp::capture_stream()));
    bp::child c = bp::launch(get_helpers_path(), args, ctx);

    bios::stream<bios::file_descriptor> is(c.get_output(desc));
    std::string word;
    is >> word;
    BOOST_CHECK_EQUAL(word, msg);

    const bp::status s = c.wait();
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_SUCCESS);
}

void test_output()
{
    check_output(STDOUT_FILENO, "message1-stdout");
    check_output(STDOUT_FILENO, "message2-stdout");
    check_output(STDERR_FILENO, "message1-stderr");
    check_output(STDERR_FILENO, "message2-stderr");
    check_output(10, "message1-10");
    check_output(10, "message2-10");
}

void check_redirect(int desc1, int desc2, const std::string& msg)
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("posix-echo-two");
    args.push_back(boost::str(boost::format("%1%") % desc1));
    args.push_back(boost::str(boost::format("%1%") % desc2));
    args.push_back(msg);

    bp::context ctx;
    ctx.output_behavior.insert(std::make_pair(
        desc1, bp::capture_stream()));
    ctx.output_behavior.insert(std::make_pair(
        desc2, bp::posix_redirect_stream(desc1)));
    bp::child c = bp::launch(get_helpers_path(), args, ctx);

    bios::stream<bios::file_descriptor> is(c.get_output(desc1));
    int dtmp;
    std::string word;
    is >> dtmp;
    BOOST_CHECK_EQUAL(dtmp, desc1);
    is >> word;
    BOOST_CHECK_EQUAL(word, msg);
    is >> dtmp;
    BOOST_CHECK_EQUAL(dtmp, desc2);
    is >> word;
    BOOST_CHECK_EQUAL(word, msg);

    const bp::status s = c.wait();
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_SUCCESS);
}

void test_redirect()
{
    check_redirect(STDOUT_FILENO, STDERR_FILENO, "message");
    check_redirect(STDERR_FILENO, STDOUT_FILENO, "message");
    check_redirect(4, 5, "message");
    check_redirect(10, 20, "message");
}

void test_default_ids()
{
    bp::context ctx;
    BOOST_CHECK_EQUAL(ctx.gid, ::getgid());
    BOOST_CHECK_EQUAL(ctx.egid, ::getegid());
    BOOST_CHECK_EQUAL(ctx.uid, ::getuid());
    BOOST_CHECK_EQUAL(ctx.euid, ::geteuid());
}

} // namespace {

bool init_unit_test()
{
    check_helpers();
    launch_tests::add<launcher, bp::context, bp::child>
        (butf::master_test_suite());
    butf::master_test_suite().add(BOOST_TEST_CASE(test_output), 0, 10);
    butf::master_test_suite().add(BOOST_TEST_CASE(test_redirect), 0, 10);
    butf::master_test_suite().add(BOOST_TEST_CASE(test_input), 0, 10);
    butf::master_test_suite().add(BOOST_TEST_CASE(test_default_ids));
    return true;
}

#else // #if defined(BOOST_PROCESS_POSIX_API)

int main() { return 0; }

#endif // #if defined(BOOST_PROCESS_POSIX_API)

// Boost.Process
// Tests for the detail::pipe class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "util/unit_test_main.hpp"
#include "boost/process/detail/pipe.hpp"
#include "boost/test/unit_test.hpp"

namespace bpd = boost::process::detail;
namespace bios = boost::iostreams;
namespace butf = boost::unit_test::framework;

namespace {

void test_read_and_write()
{
    const char test[] = "test";
    bpd::pipe p;
    // XXX This assumes that the pipe's buffer is big enough to accept
    // the data written without blocking!
    std::streamsize ss = p.wend().write(test, sizeof(test));
    BOOST_CHECK_EQUAL(ss, std::streamsize(sizeof(test)));
    char tmp[sizeof(test)+1];
    ss = p.rend().read(tmp, sizeof(tmp));
    BOOST_CHECK_EQUAL(ss, std::streamsize(sizeof(test)));
    BOOST_CHECK_EQUAL(test, tmp);
}

} // namespace {

bool init_unit_test()
{
    butf::master_test_suite().add(BOOST_TEST_CASE(test_read_and_write));
    return true;
}

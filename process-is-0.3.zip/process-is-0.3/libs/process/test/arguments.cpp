// Boost.Process
// Tests for command line construction class.
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#include "util/unit_test_main.hpp"
#include "util/use_helpers.hpp"
#include "boost/process/child.hpp"
#include "boost/process/context.hpp"
#include "boost/process/operations.hpp"
#include "boost/process/status.hpp"
#include "boost/test/unit_test.hpp"
#if defined(BOOST_PROCESS_POSIX_API)
    #include "boost/process/detail/posix_ops.hpp"
    #include <cstddef>
    #include <cstring>
#elif defined(BOOST_PROCESS_WIN32_API)
    #include "boost/process/detail/win32_ops.hpp"
    #include <tchar.h>
#else
    #error "Unsupported platform."
#endif
#include <cstdlib>
#include <string>
#include <vector>

namespace bp = boost::process;
namespace bpd = boost::process::detail;
namespace butf = boost::unit_test::framework;

namespace {

std::string get_argument(const std::string& word)
{
    std::vector<std::string> args;
    args.push_back("helpers");
    args.push_back("echo-quoted");
    args.push_back(word);

    bp::context ctx;
#if defined(BOOST_PROCESS_WIN32_API)
    ctx.stdout_behavior = bp::capture_stream();
#elif defined(BOOST_PROCESS_POSIX_API)
    ctx.output_behavior.insert(std::make_pair(
        STDOUT_FILENO, bp::capture_stream()));
#endif // #elif defined(BOOST_PROCESS_POSIX_API)

    bp::child c = bp::launch(get_helpers_path(), args, ctx);

    char buf[256]; // FIXME
    std::streamsize ss = c.get_stdout().read(buf, sizeof(buf));
    BOOST_REQUIRE(ss > 0);
    std::string result(buf, ss);

    const bp::status s = c.wait();
    BOOST_REQUIRE(s.exited());
    BOOST_CHECK_EQUAL(s.exit_status(), EXIT_SUCCESS);

    return result;
}

void test_quoting()
{
    BOOST_CHECK_EQUAL(get_argument("foo"), ">>>foo<<<");
    BOOST_CHECK_EQUAL(get_argument("foo "), ">>>foo <<<");
    BOOST_CHECK_EQUAL(get_argument(" foo"), ">>> foo<<<");
    BOOST_CHECK_EQUAL(get_argument("foo bar"), ">>>foo bar<<<");

    BOOST_CHECK_EQUAL(get_argument("foo\"bar"), ">>>foo\"bar<<<");
    BOOST_CHECK_EQUAL(get_argument("foo\"bar\""), ">>>foo\"bar\"<<<");
    BOOST_CHECK_EQUAL(get_argument("\"foo\"bar"), ">>>\"foo\"bar<<<");
    BOOST_CHECK_EQUAL(get_argument("\"foo bar\""), ">>>\"foo bar\"<<<");

    BOOST_CHECK_EQUAL(get_argument("*"), ">>>*<<<");
    BOOST_CHECK_EQUAL(get_argument("?*"), ">>>?*<<<");
    BOOST_CHECK_EQUAL(get_argument("[a-z]*"), ">>>[a-z]*<<<");
}

#if defined(BOOST_PROCESS_POSIX_API)
void test_collection_to_posix_argv()
{
    std::vector<std::string> args;
    args.push_back("program");
    args.push_back("arg1");
    args.push_back("arg2");
    args.push_back("arg3");

    std::pair<std::size_t, char**> p = bpd::collection_to_posix_argv(args);
    std::size_t argc = p.first;
    char** argv = p.second;

    BOOST_REQUIRE_EQUAL(argc, static_cast<std::size_t>(4));

    BOOST_REQUIRE(std::strcmp(argv[0], "program") == 0);
    BOOST_REQUIRE(std::strcmp(argv[1], "arg1") == 0);
    BOOST_REQUIRE(std::strcmp(argv[2], "arg2") == 0);
    BOOST_REQUIRE(std::strcmp(argv[3], "arg3") == 0);
    BOOST_REQUIRE(argv[4] == 0);

    delete [] argv[0];
    delete [] argv[1];
    delete [] argv[2];
    delete [] argv[3];
    delete [] argv;
}
#endif // #if defined(BOOST_PROCESS_POSIX_API)

#if defined(BOOST_PROCESS_WIN32_API)
void test_collection_to_win32_cmdline()
{
    std::vector<std::string> args;
    args.push_back("program");
    args.push_back("arg1");
    args.push_back("arg2");
    args.push_back("arg3");

    boost::shared_array<TCHAR> cmdline = bpd::collection_to_win32_cmdline(args);
    BOOST_REQUIRE(::_tcscmp(cmdline.get(),
                            TEXT("program arg1 arg2 arg3")) == 0);
}
#endif // #if defined(BOOST_PROCESS_WIN32_API)

} // namespace {

bool init_unit_test()
{
    check_helpers();
    butf::master_test_suite().add(BOOST_TEST_CASE(test_quoting));
#if defined(BOOST_PROCESS_POSIX_API)
    butf::master_test_suite()
        .add(BOOST_TEST_CASE(test_collection_to_posix_argv));
#elif defined(BOOST_PROCESS_WIN32_API)
    butf::master_test_suite()
        .add(BOOST_TEST_CASE(test_collection_to_win32_cmdline));
#endif
    return true;
}

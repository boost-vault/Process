// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#define BOOST_PROCESS_SOURCE
#include "boost/process/detail/impl/file_handle.hpp"

// Boost.Process
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

/// \file boost/process/operations.hpp
///
/// Provides miscellaneous free functions.

#ifndef BOOST_PROCESS_OPERATIONS_HPP_172625
#define BOOST_PROCESS_OPERATIONS_HPP_172625

#include "boost/process/child.hpp"
#include "boost/process/context.hpp"
#include "boost/process/detail/file_handle.hpp"
#include "boost/process/exceptions.hpp"
#include "boost/assert.hpp"
#include "boost/throw_exception.hpp"
#include "boost/variant/get.hpp"
#if defined(BOOST_PROCESS_POSIX_API)
    #include "boost/process/detail/posix_ops.hpp"
#elif defined(BOOST_PROCESS_WIN32_API)
    #include "boost/process/detail/win32_ops.hpp"
    #include <tchar.h>
    #define WIN32_LEAN_AND_MEAN
    #include <windows.h>
#else
    #error "Unsupported platform."
#endif
#include <string>
#include <vector>

namespace boost {
namespace process {

/// \brief Locates a program in the path.
///
/// Locates the executable program \a file in all the directory components
/// specified in \a path. If \a path is empty, the value of the PATH
/// environment variable is used.
///
/// The path variable is interpreted following the same conventions used
/// to parse the PATH environment variable in the underlying platform.
///
/// \throw not_found_error&lt;std::string&gt; If the file cannot be found
/// in the path.
///
BOOST_PROCESS_DECL
std::string
find_executable_in_path(const std::string& file, std::string path = "");

BOOST_PROCESS_DECL
std::string
executable_to_progname(const std::string& exe);

/// \brief Starts a new child process.
///
/// Launches a new process based on the binary image specified by the
/// executable, the set of arguments to be passed to it and several
/// parameters that describe the execution context.
///
/// \remark <b>Blocking remarks</b>: This function may block if the device
/// holding the executable blocks when loading the image. This might
/// happen if, e.g., the binary is being loaded from a network share.
///
/// \return A handle to the new child process.
///
template<class Executable, class Arguments, class Context>
child
launch(const Executable& exe, const Arguments& args, const Context& ctx)
{
    BOOST_ASSERT(!args.empty());

    // Validate execution context.
    // XXX Should this be a 'validate()' method in it?
    BOOST_ASSERT(!ctx.work_directory.empty());

#if defined(BOOST_PROCESS_POSIX_API)
    return child(detail::posix_start(exe, args, ctx));
#elif defined(BOOST_PROCESS_WIN32_API)
    return child(detail::win32_start(exe, args, ctx));
#endif
}

/// \brief Launches a shell-based command.
///
/// Executes the given command through the default system shell. The
/// command is subject to pattern expansion, redirection and pipelining.
/// The shell is launched as described by the parameters in the execution
/// context.
///
/// This function behaves similarly to the system(3) system call. In a
/// POSIX system, the command is fed to /bin/sh whereas under a Win32
/// system, it is fed to cmd.exe. It is difficult to write portable
/// commands as the first parameter, but this function comes in handy in
/// multiple situations.
///
template<class Context>
child
launch_shell(const std::string& command, const Context& ctx)
{
    std::string exe;
    std::vector<std::string> args;

#if defined(BOOST_PROCESS_POSIX_API)
    exe = "/bin/sh";
    args.push_back("sh");
    args.push_back("-c");
    args.push_back(command);
#elif defined(BOOST_PROCESS_WIN32_API)
    TCHAR buf[MAX_PATH];
    UINT res = ::GetSystemDirectory(buf, MAX_PATH);
    if (res == 0)
        boost::throw_exception
            (system_error("boost::process::launch_shell",
                          "GetWindowsDirectory failed", ::GetLastError()));
    BOOST_ASSERT(res < MAX_PATH);

    exe = std::string(buf) + "\\cmd.exe";
    args.push_back("cmd");
    args.push_back("/c");
    args.push_back(command);
#endif

    return launch(exe, args, ctx);
}

/// \brief Launches a pipelined set of child processes.
///
/// Given a collection of pipeline_entry objects describing how to launch
/// a set of child processes, spawns them all and connects their inputs and
/// outputs in a way that permits pipelined communication.
///
/// \pre Let 1..N be the processes in the collection: the input behavior of
///      the 2..N processes must be set to close_stream().
/// \pre Let 1..N be the processes in the collection: the output behavior of
///      the 1..N-1 processes must be set to close_stream().
///
/// \remark <b>Blocking remarks</b>: This function may block if the
///         device holding the executable of one of the entries
///         blocks when loading the image. This might happen if, e.g.,
///         the binary is being loaded from a network share.
///
/// \return A set of Child objects that represent all the processes spawned
///         by this call. You should use wait_children() to wait for their
///         termination.
template<class Entries>
children
launch_pipeline(const Entries& entries)
{
    BOOST_ASSERT(entries.size() >= 2);
//  BOOST_ASSERT(boost::get<close_stream>(&entries[0].context.stdout_behavior));

    // Method's result value.
    children cs;

    // The pipes used to connect the pipeline's internal process.
    boost::scoped_array<detail::pipe> pipes
        (new detail::pipe[entries.size() - 1]);

#if defined(BOOST_PROCESS_POSIX_API)
    // Configure and spawn the pipeline's first process.
    {
        typename Entries::value_type::context_type ctx(entries[0].context);

        use_handle uho(pipes[0].wend());
        ctx.output_behavior[STDOUT_FILENO] = uho;

        child ch(detail::posix_start(entries[0].executable,
                                     entries[0].arguments,
                                     ctx));

        cs.push_back(ch);
    }

    // Configure and spawn the pipeline's internal processes.
    for (typename Entries::size_type i = 1; i < entries.size() - 1; i++) {
        typename Entries::value_type::context_type ctx(entries[i].context);

//        BOOST_ASSERT(boost::get<close_stream>(&ctx.stdin_behavior));
        use_handle uhi(pipes[i - 1].rend());
        ctx.input_behavior[STDIN_FILENO] = uhi;
//        BOOST_ASSERT(boost::get<close_stream>(&ctx.stdout_behavior));
        use_handle uho(pipes[i].wend());
        ctx.output_behavior[STDOUT_FILENO] = uho;

        child ch(detail::posix_start(entries[i].executable,
                                     entries[i].arguments,
                                     ctx));

        cs.push_back(ch);
    }

    // Configure and spawn the pipeline's last process.
    {
        const typename Entries::size_type last = entries.size() - 1;
        typename Entries::value_type::context_type ctx(entries[last].context);

//        BOOST_ASSERT(boost::get<close_stream>(&ctx.stdin_behavior));
        use_handle uhi(pipes[last - 1].rend());
        ctx.input_behavior[STDIN_FILENO] = uhi;

        child ch(detail::posix_start(entries[last].executable,
                                     entries[last].arguments,
                                     ctx));

        cs.push_back(ch);
    }
#elif defined(BOOST_PROCESS_WIN32_API)
    // Configure and spawn the pipeline's first process.
    {
        typename Entries::value_type::context_type ctx(entries[0].context);

        use_handle uho(pipes[0].wend());
        ctx.stdout_behavior = uho;

        child ch(detail::win32_start(entries[0].executable,
                                     entries[0].arguments,
                                     ctx));

        uho.file_descriptor().close();

        cs.push_back(ch);
    }

    // Configure and spawn the pipeline's internal processes.
    for (typename Entries::size_type i = 1; i < entries.size() - 1; i++) {
        typename Entries::value_type::context_type ctx(entries[i].context);

        BOOST_ASSERT(boost::get<close_stream>(&ctx.stdin_behavior));
        use_handle uhi(pipes[i - 1].rend());
        ctx.stdin_behavior = uhi;

        BOOST_ASSERT(boost::get<close_stream>(&ctx.stdout_behavior));
        use_handle uho(pipes[i].wend());
        ctx.stdout_behavior = uho;

        child ch(detail::win32_start(entries[i].executable,
                                     entries[i].arguments,
                                     ctx));

        uhi.file_descriptor().close();
        uho.file_descriptor().close();

        cs.push_back(ch);
    }

    // Configure and spawn the pipeline's last process.
    {
        const typename Entries::size_type last = entries.size() - 1;
        typename Entries::value_type::context_type ctx(entries[last].context);

        BOOST_ASSERT(boost::get<close_stream>(&ctx.stdin_behavior));
        use_handle uhi(pipes[last - 1].rend());
        ctx.stdin_behavior = uhi;

        child ch(detail::win32_start(entries[last].executable,
                                     entries[last].arguments,
                                     ctx));

        uhi.file_descriptor().close();

        cs.push_back(ch);
    }
#endif

    return cs;
}

/// \brief Waits for a collection of children to terminate.
///
/// Given a collection of Child objects (such as std::vector<child> or
/// the convenience children type), waits for the termination of all of
/// them.
///
/// \remark <b>Blocking remarks</b>: This call blocks if any of the
/// children processes in the collection has not finalized execution and
/// waits until it terminates.
///
/// \return The exit status of the first process that returns an error
///         code or, if all of them executed correctly, the exit status
///         of the last process in the collection.
template<class Children>
const status
wait_children(Children& cs)
{
    BOOST_ASSERT(cs.size() >= 2);

    typename Children::iterator iter = cs.begin();
    while (iter != cs.end()) {
        const status s = iter->wait();
        iter++;
        if (iter == cs.end())
            return s;
        else if (!s.exited() || s.exit_status() != EXIT_SUCCESS) {
            while (iter != cs.end()) {
                iter->wait();
                iter++;
            }
            return s;
        }
    }

    BOOST_ASSERT(false);
    return cs.begin()->wait();
}

} // namespace process
} // namespace boost

#ifdef BOOST_PROCESS_HEADER_ONLY
#include "boost/process/detail/impl/operations.hpp"
#endif

#endif

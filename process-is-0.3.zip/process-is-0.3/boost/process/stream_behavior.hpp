// Boost.Process
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

/// \file boost/process/stream_behavior.hpp
///
/// Includes the declaration of the stream_behavior class and associated
/// free functions.

#ifndef BOOST_PROCESS_STREAM_BEHAVIOR_HPP_172214
#define BOOST_PROCESS_STREAM_BEHAVIOR_HPP_172214

#include "boost/process/config.hpp"
#include "boost/iostreams/device/file_descriptor.hpp"
#ifdef BOOST_MSVC
#pragma warning(push)
// 4345 behavior change: an object of POD type constructed with a
//      an initializer of the form () will be default-initialized
#pragma warning(disable: 4345)
#endif
#include "boost/variant/variant.hpp"
#ifdef BOOST_MSVC
#pragma warning(pop)
#endif

#ifdef BOOST_MSVC
#pragma warning(push)
// 4251 * needs to have dll-interface to be used by clients of *
// 4275 * used as base for dll-interface class *
#pragma warning(disable: 4251 4275)
#endif

namespace boost {
namespace process {

/// The child's stream is closed upon startup so that it will not
/// have any access to it.
///
class BOOST_PROCESS_DECL close_stream
{};

/// The child's stream is connected to the parent by using an
/// anonymous pipe so that they can send and receive data to/from
/// each other.
///
class BOOST_PROCESS_DECL capture_stream
{};

/// The child's stream is connected to the same stream used by the
/// parent. In other words, the corresponding parent's stream is
/// inherited.
///
class BOOST_PROCESS_DECL inherit_stream
{};

/// The child's stream is connected to child's standard output.
/// This is typically used when configuring the standard error
/// stream.
///
class BOOST_PROCESS_DECL redirect_stream_to_stdout
{};

/// The child's stream is redirected to a null device so that its
/// input is always zero or its output is lost, depending on
/// whether the stream is an input or an output one. It is
/// important to notice that this is different from close because
/// the child is still able to write data. If we closed, e.g.
/// stdout, the child might not work at all!
///
class BOOST_PROCESS_DECL silence_stream
{};

#if defined(BOOST_PROCESS_POSIX_API) || defined(BOOST_PROCESS_DOXYGEN)
/// The child redirects the stream's output to the provided file
/// descriptor. This is a generalization of the portable
/// redirect_to_stdout behavior.
///
class BOOST_PROCESS_DECL posix_redirect_stream
{
public:
    explicit posix_redirect_stream(int to)
    : desc_to_(to)
    {}
    int desc_to() const { return desc_to_; }
private:
    int desc_to_;
};
#endif // #if defined(BOOST_PROCESS_POSIX_API) || defined(BOOST_PROCESS_DOXYGEN)

class BOOST_PROCESS_DECL use_handle
{
public:
    explicit use_handle(const boost::iostreams::file_descriptor& fd)
    : fd_(fd)
    {}
    boost::iostreams::file_descriptor file_descriptor() const
    {
        return fd_;
    }
private:
    boost::iostreams::file_descriptor fd_;
};

class BOOST_PROCESS_DECL use_file
{
public:
    explicit use_file(const std::string& file)
    : file_(file)
    {}
    const std::string& file() const { return file_; }
private:
    std::string file_;
};

/// \brief Describes the possible states for a communication stream.
///
/// Describes the possible states for a child's communication stream.
///
typedef boost::variant<
    close_stream
  , capture_stream
  , inherit_stream
  , redirect_stream_to_stdout
  , silence_stream
#if defined(BOOST_PROCESS_POSIX_API) || defined(BOOST_PROCESS_DOXYGEN)
  , posix_redirect_stream
#endif
  , use_handle
  , use_file
  > stream_behavior;

} // namespace process
} // namespace boost

#ifdef BOOST_MSVC
#pragma warning(pop)
#endif

#endif

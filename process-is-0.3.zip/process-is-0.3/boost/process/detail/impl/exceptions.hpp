// Boost.Process
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#ifndef BOOST_PROCESS_EXCEPTIONS_HPP_114959
#define BOOST_PROCESS_EXCEPTIONS_HPP_114959

#include "boost/process/exceptions.hpp"

namespace boost {
namespace process {

BOOST_PROCESS_INLINE_IF_HEADER_ONLY
const char*
system_error::what() const throw()
{
    try {
        if (message_.length() == 0) {
            message_ = std::string(std::runtime_error::what()) + ": ";

#if defined(BOOST_PROCESS_POSIX_API)
            message_ += ::strerror(sys_err_);
#elif defined(BOOST_PROCESS_WIN32_API)
            TCHAR* msg = 0;
            if (::FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM |
                                FORMAT_MESSAGE_ALLOCATE_BUFFER,
                                0, sys_err_, 0,
                                reinterpret_cast<LPTSTR>(&msg),
                                0, 0) == 0)
                message_ += "Unexpected error in FormatMessage";
            else {
                BOOST_ASSERT(msg != 0);
                message_ += msg;
                LocalFree(msg);
            }
#endif
        }

        return message_.c_str();
    } catch (...) {
        return "Unable to format system_error message";
    }
}

} // namespace process
} // namespace boost

#endif

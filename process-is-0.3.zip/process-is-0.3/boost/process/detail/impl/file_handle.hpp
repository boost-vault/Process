// Boost.Process
//
// Copyright (c) 2006 Julio M. Merino Vidal.
// Copyright 2008 Ilya Sokolov
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt.)

#ifndef BOOST_PROCESS_FILE_HANDLE_HPP_114341
#define BOOST_PROCESS_FILE_HANDLE_HPP_114341

#include "boost/process/detail/file_handle.hpp"
#include "boost/process/exceptions.hpp"
#include "boost/assert.hpp"
#include "boost/throw_exception.hpp"
#if defined(BOOST_PROCESS_POSIX_API)
    #include <unistd.h>
    #include <cerrno>
#elif defined(BOOST_PROCESS_WIN32_API)
    #define WIN32_LEAN_AND_MEAN
    #include <windows.h>
#endif

namespace boost {
namespace process {
namespace detail {

#if defined(BOOST_PROCESS_WIN32_API)

BOOST_PROCESS_INLINE_IF_HEADER_ONLY boost::iostreams::file_descriptor
win32_dup_fd(const boost::iostreams::file_descriptor& fd, bool inheritable)
{
    HANDLE h;
    if (::DuplicateHandle(::GetCurrentProcess(), fd.handle(),
                          ::GetCurrentProcess(), &h,
                          0, inheritable, DUPLICATE_SAME_ACCESS) == 0)
        boost::throw_exception
            (system_error("boost::process::detail::file_handle::win32_dup",
                          "DuplicateHandle failed", ::GetLastError()));
    return boost::iostreams::file_descriptor(h, true);
}

BOOST_PROCESS_INLINE_IF_HEADER_ONLY boost::iostreams::file_descriptor
win32_std_fd(unsigned long d, bool inheritable)
{
    BOOST_ASSERT(d == STD_INPUT_HANDLE ||
                 d == STD_OUTPUT_HANDLE ||
                 d == STD_ERROR_HANDLE);
    HANDLE h = ::GetStdHandle(d);
    if (h == INVALID_HANDLE_VALUE)
        boost::throw_exception
            (system_error("boost::process::detail::file_handle::win32_std_fd",
                          "GetStdHandle failed", ::GetLastError()));
    boost::iostreams::file_descriptor fd(h, false);
    return win32_dup_fd(fd, inheritable);
}

BOOST_PROCESS_INLINE_IF_HEADER_ONLY void
win32_set_inheritable_fd(const boost::iostreams::file_descriptor& fd, bool i)
{
    BOOST_ASSERT(is_valid_fd(fd)); // FIXME?
    if (::SetHandleInformation(fd.handle(), HANDLE_FLAG_INHERIT,
                               i ? HANDLE_FLAG_INHERIT : 0) == 0)
        boost::throw_exception
            (system_error("boost::process::detail::file_handle::"
                          "win32_set_inheritable_fd",
                          "SetHandleInformation failed",
                          ::GetLastError()));
}

#endif // #if defined(BOOST_PROCESS_WIN32_API)

#if defined(BOOST_PROCESS_POSIX_API)

BOOST_PROCESS_INLINE_IF_HEADER_ONLY void
posix_dup2_fd(const boost::iostreams::file_descriptor& fd1,
              const boost::iostreams::file_descriptor& fd2)
{
    if (::dup2(fd1.handle(), fd2.handle()) == -1)
        boost::throw_exception
            (system_error("boost::process::detail::file_handle::posix_dup2_fd",
                          "dup2(2) failed", errno));
}

#endif // #if defined(BOOST_PROCESS_POSIX_API)

} // namespace detail
} // namespace process
} // namespace boost

#endif
